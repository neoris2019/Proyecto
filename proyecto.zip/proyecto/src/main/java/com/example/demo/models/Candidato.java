package com.example.demo.models;

public class Candidato {

	public String nombre;
	public String perfil;
	public String aprobado;
	public String email;

	public Candidato() {
	}

	public Candidato(String nombre, String perfil, String aprobado, String email) {
		this.nombre = nombre;
		this.perfil = perfil;
		this.aprobado = aprobado;
		this.email = email;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getPerfil() {
		return perfil;
	}

	public void setPerfil(String perfil) {
		this.perfil = perfil;
	}

	public String getAprobado() {
		return aprobado;
	}

	public void setAprobado(String aprobado) {
		this.aprobado = aprobado;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

}
