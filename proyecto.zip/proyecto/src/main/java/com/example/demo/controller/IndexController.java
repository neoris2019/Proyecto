package com.example.demo.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import com.example.demo.models.Candidato;

@Controller
@RequestMapping("/app")
public class IndexController {

	@Value("${texto.indexcontroller.index.titulo}")
	private String textoIndex;
	
	@Value("${texto.indexcontroller.candidato.titulo}")
	private String textoCandidato;
	
	@Value("${texto.indexcontroller.listar.titulo}")
	private String textoListar;

	
	@GetMapping({"/index" , "/"})
	public String index( Model model )
	{
		model.addAttribute("titulo" , textoIndex);
		return "index";
	}
	
	@RequestMapping("/datos")
	public String candidato( Model model )
	{
		Candidato candidato = new Candidato( );
		candidato.setNombre( "Vlad" );
		candidato.setPerfil( "Desarrollador" );
		candidato.setAprobado( "Aprobado" );
		candidato.setEmail( "vladimir.estrada@neoris.com" );
		model.addAttribute( "titulo" , textoCandidato.concat(candidato.nombre));
		model.addAttribute( "candidato" , candidato );
		return "datos";
	}
	
	@RequestMapping("/registrar")
	public String candidato2( Model model )
	{
		Candidato candidato = new Candidato( );
		candidato.setNombre( "Vlad" );
		candidato.setPerfil( "Desarrollador" );
		candidato.setAprobado( "Aprobado" );
		candidato.setEmail( "vladimir.estrada@neoris.com" );
		model.addAttribute( "titulo" , textoCandidato.concat(candidato.nombre));
		model.addAttribute( "candidato" , candidato );
		return "registrar";
	}
	
	@RequestMapping("/registrar2")
	public String candidato3( Model model )
	{
		Candidato candidato = new Candidato( );
		candidato.setNombre( "Vlad" );
		candidato.setPerfil( "Desarrollador" );
		candidato.setAprobado( "Aprobado" );
		candidato.setEmail( "vladimir.estrada@neoris.com" );
		model.addAttribute( "titulo" , textoCandidato.concat(candidato.nombre));
		model.addAttribute( "candidato" , candidato );
		return "registrar2";
	}
	
	@RequestMapping("/registrar3")
	public String candidato4( Model model )
	{
		Candidato candidato = new Candidato( );
		candidato.setNombre( "Vlad" );
		candidato.setPerfil( "Desarrollador" );
		candidato.setAprobado( "Aprobado" );
		candidato.setEmail( "vladimir.estrada@neoris.com" );
		model.addAttribute( "titulo" , textoCandidato.concat(candidato.nombre));
		model.addAttribute( "candidato" , candidato );
		return "registrar3";
	}
	
	@RequestMapping("/registrar4")
	public String candidato5( Model model )
	{
		Candidato candidato = new Candidato( );
		candidato.setNombre( "Vlad" );
		candidato.setPerfil( "Desarrollador" );
		candidato.setAprobado( "Aprobado" );
		candidato.setEmail( "vladimir.estrada@neoris.com" );
		model.addAttribute( "titulo" , textoCandidato.concat(candidato.nombre));
		model.addAttribute( "candidato" , candidato );
		return "registrar4";
	}
	
	@RequestMapping("/listar")
	public String listar( Model model )
	{
		model.addAttribute( "titulo" , textoListar );
		return "listar";
	}
	
	@RequestMapping("/listado")
	public String listado( Model model )
	{
		model.addAttribute( "titulo" , textoListar );
		return "listado";
	}
	@RequestMapping("/listado2")
	public String listado2( Model model )
	{
		model.addAttribute( "titulo" , textoListar );
		return "listado2";
	}
	@RequestMapping("/listado3")
	public String listado3( Model model )
	{
		model.addAttribute( "titulo" , textoListar );
		return "listado3";
	}
	
	
	@ModelAttribute("candidatos")
	public List<Candidato> problarCandidato( )
	{
		List<Candidato> candidatos = new ArrayList<>( );
		candidatos.add( new Candidato("Orlando","Desarrollador","No","orlando@neoris.com") );
		candidatos.add( new Candidato("Angelica","Analista","Sí","diana@neoris.com") );
		candidatos.add( new Candidato("Omar","Diseñador","No","omar@neoris.com") );
		candidatos.add( new Candidato("Sergio","Tester","Sí","sergio@neoris.com") );	
		return candidatos;
	}
	
	
	
}
