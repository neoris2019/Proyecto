package com.neoris.springboot.web.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootWebProyecto1Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootWebProyecto1Application.class, args);
	}

}
