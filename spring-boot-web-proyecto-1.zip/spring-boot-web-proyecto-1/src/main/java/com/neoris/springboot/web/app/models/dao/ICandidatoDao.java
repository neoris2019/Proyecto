package com.neoris.springboot.web.app.models.dao;

import java.util.List;

import com.neoris.springboot.web.app.models.entity.Candidato;



public interface ICandidatoDao {
	
	public List<Candidato> findAll();
	public void save(Candidato candidato);

}
