package com.neoris.springboot.web.app.controllers;

import java.util.Map;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.neoris.springboot.web.app.models.dao.ICandidatoDao;
import com.neoris.springboot.web.app.models.entity.Candidato;

@Controller
@RequestMapping("/candidatos")
public class CandidatoController {
	
	@Autowired
	@Qualifier("candidatoDaoJPA")
	private ICandidatoDao candidatoDao;
	
	@RequestMapping(value="/listarCandidatos", method=RequestMethod.GET)
	public String listar(Model model) {
		model.addAttribute("titulo", "Listado de Candidatos");
		model.addAttribute("candidatos", candidatoDao.findAll());
		return "listarCandidatos";
	}
	
	
	@RequestMapping(value="/nuevoCandidato")
	public String crear(Map<String, Object>model) {
		Candidato candidato = new Candidato();
		model.put("candidato",  candidato);
		model.put("titulo", "Formulario de candidato");
		return "nuevoCandidato";
	}
	
	@RequestMapping(value="/nuevoCandidato", method=RequestMethod.POST)
	public String guardar(@Valid Candidato candidato, BindingResult result, Model model) {
		if(result.hasErrors()) {
			model.addAttribute("titulo","Formulario de candidato");
			return "nuevoCandidato";
		}
		candidatoDao.save(candidato);
		return "redirect:listarCandidatos";
	}

}
