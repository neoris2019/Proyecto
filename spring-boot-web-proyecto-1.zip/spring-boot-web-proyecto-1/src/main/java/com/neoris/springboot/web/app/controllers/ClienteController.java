package com.neoris.springboot.web.app.controllers;

import java.util.Map;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.neoris.springboot.web.app.models.dao.IClienteDao;
import com.neoris.springboot.web.app.models.entity.Cliente;

@Controller
@RequestMapping("/clientes")
public class ClienteController {
	
	@Autowired
	@Qualifier("clienteDaoJPA")
	private IClienteDao clienteDao;
	
	@RequestMapping(value="/listarClientes", method=RequestMethod.GET)
	public String listar(Model model) {
		model.addAttribute("titulo", "Listado de Clientes");
		model.addAttribute("clientes", clienteDao.findAll());
		return "listarClientes";
	}
	
	@RequestMapping(value="/nuevoCliente")
	public String crear(Map<String, Object> model) {
		Cliente cliente = new Cliente();
		model.put("cliente",  cliente);
		model.put("titulo", "Formulario de cliente");
		return "nuevoCliente";
	}
	
	@RequestMapping(value="/nuevoCliente/{id}")
	public String editar(@PathVariable(value="id") Long id, Map<String,Object> model) {
		Cliente cliente = null;
		if(id > 0) {
			cliente = clienteDao.findOne(id);
		}else {
			return "redirect:/listarClientes";
		}
		model.put("cliente",cliente);
		model.put("titulo","Editar Cliente");
		return "/nuevoCliente";
	}
	
	
	@RequestMapping(value="/nuevoCliente", method=RequestMethod.POST)
	public String guardar(@Valid Cliente cliente, BindingResult result, Model model) {
		if(result.hasErrors()) {
			model.addAttribute("titulo", "Formulario de cliente");
			return "nuevoCliente";
		}
		clienteDao.save(cliente);
		return "redirect:listarClientes";
	}
	
	
	
	
}
